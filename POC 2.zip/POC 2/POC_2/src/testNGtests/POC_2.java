package testNGtests;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import webpages.HomePage;
import webpages.LoginPage;
import webpages.MyAccount;

@Listeners(testNGtests.ListnersClass.class)

public class POC_2 {
	
	WebDriver dr;
	Logger log = Logger.getLogger("devpinoyLogger");
	
	String url = "http://demowebshop.tricentis.com";
	String actual;
	String expected;
	SoftAssert sa;
	
	HomePage hp;
	LoginPage lp;
	MyAccount ma;
	
	String[][] data;
	
	
	@BeforeClass
	public void launhUrlInBrowser() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();
		dr.get(url);
		
		hp = new HomePage(dr);
		lp = new LoginPage(dr);
		ma = new MyAccount(dr);
		
		data = lp.readExcel();
	}
	
	
	@Test
	public void test_1_homepage(){		
		expected = "Demo Web Shop";
		actual = hp.verifyTitle();
		
		sa = new SoftAssert();
		sa.assertEquals(actual, expected);
		
		log.info("Expected: " + expected);
		log.info("Actual: " + actual);
		sa.assertAll();
	}
	
	@Test
	public void test_2_homepage(){		
		expected = "Register";
		actual = hp.verifyRegisterLink();
		
		sa = new SoftAssert();
		sa.assertEquals(actual, expected);
		log.info("Expected: " + expected);
		log.info("Actual: " + actual);
		sa.assertAll();
		
	}
	
	@Test
	public void test_3_homepage(){
		expected = "Log in";
		actual = hp.verifyLoginLink();
		
		sa = new SoftAssert();
		sa.assertEquals(actual, expected);
		log.info("Expected: " + expected);
		log.info("Actual: " + actual);
		
		sa.assertAll();
	}
	
	@Test(dataProvider = "ForLoginPage")
	public void test_4_Login(String email, String pass, String expected) {		
		hp.clickLogin();
		
		actual = lp.login(email, pass, expected);
		
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(actual, expected);
		log.info("Expected: " + expected);
		log.info("Actual: " + actual);
		ma.checkLogout();
		lp.refreshLoginPage();
		
	}
	
	@DataProvider(name = "ForLoginPage")
	public String[][] homepageData() {			
		return data;
	}
	
}
