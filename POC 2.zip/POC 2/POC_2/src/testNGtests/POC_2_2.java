package testNGtests;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class POC_2_2 extends POC_2{
	
	
	
	
	String actual;
	String expected;
	@AfterClass
	public void closeDriver() {
		new WebDriverWait(dr, 5);
		dr.quit();
	}
	
	@Test
	public void test_5_Login() {
		hp.clickLogin();
		lp.login(data[0][0], data[0][1], data[0][2]);
		
		
		expected = "Demo Web Shop";
		actual = ma.verifyTitle();
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(actual, expected);
		log.info("Expected: " + expected);
		log.info("Actual: " + actual);
		sa.assertAll();
	}

	
}
