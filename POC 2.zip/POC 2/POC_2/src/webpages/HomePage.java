package webpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
	
	WebDriver dr;
	String actual;
	
	@FindBy(xpath = "//a[@href = '/register']")
	WebElement register;
	
	@FindBy(xpath = "//a[text() = 'Log in']")
	WebElement login;
	
	
	public HomePage(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}

	public String verifyTitle() {

		WebDriverWait wt = new WebDriverWait(dr, 4);
		wt.until(ExpectedConditions.titleContains("Demo Web Shop"));
		actual = dr.getTitle();
		return actual;
	}
	
	public String verifyRegisterLink() {
		actual = register.getText();
		return actual;
	}
	
	public String verifyLoginLink() {
		actual = login.getText();
		return actual;
	}
	
	public void clickLogin() {
		login.click();
	}
		
	
	
}
