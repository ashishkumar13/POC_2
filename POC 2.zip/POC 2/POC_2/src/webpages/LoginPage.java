package webpages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver dr;
	String actualResult, actualResult2;
	
	
	public LoginPage(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
		
	}
	
	@FindBy(xpath = "//input[@id = 'Email']")
	WebElement emailField;
	
	@FindBy(xpath = "//input[@id = 'Password']")
	WebElement passField;
	
	@FindBy(xpath = "//input[@class = 'button-1 login-button']")
	WebElement loginButton;
	
	public String login(String email, String password, String expectedResult) {
		actualResult = "";
	
		emailField.sendKeys(email);
		passField.sendKeys(password);
		loginButton.click();	
		boolean b1;
		
		try {
			
			b1 = dr.findElement(By.xpath("//span[@for = 'Email']")).isDisplayed();
			if(b1) {									
				actualResult += dr.findElement(By.xpath("//span[@for = 'Email']")).getText();
			}		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		try {
			b1 = dr.findElement(By.xpath("//div[@class = 'validation-summary-errors']")).isDisplayed();
			
			if(b1) {
				actualResult = dr.findElement(By.xpath("//div[@class = 'validation-summary-errors']")).getText();
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			b1 = dr.findElement(By.xpath("//div[@class = 'validation-summary-errors']")).isDisplayed();
			
			if(b1) {
				actualResult = dr.findElement(By.xpath("//div[@class = 'validation-summary-errors']")).getText();
				
			}	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			
			if(dr.findElement(By.xpath("//a[@href = '/logout']")).isDisplayed()) {
				WebElement proName = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a"));
				actualResult = proName.getText();
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	
		return actualResult;
	}
	
	public void refreshLoginPage() {
		dr.get("http://demowebshop.tricentis.com/login");
	}
	
	public String[][] readExcel() {
		File file = new File("POC_2_Login.xlsx");
		
		String[][] data = new String[2][3];
		try {
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			
			XSSFSheet sh = wb.getSheet("DemoLoginDetail");
			XSSFRow row;
			XSSFCell email, pass, expected;			
			
			
			for(byte i = 0; i< 2; i++) {
				row = sh.getRow(i+1);
				
				email = row.getCell(0);
				data[i][0] = email.getStringCellValue();
								
				pass = row.getCell(1);
				data[i][1] = pass.getStringCellValue();
				
				expected = row.getCell(2);
				data[i][2] = expected.getStringCellValue();
			}
			
			
			wb.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return data;
		
	}
	

}
