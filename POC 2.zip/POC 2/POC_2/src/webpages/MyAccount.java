package webpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyAccount {
	
	WebDriver dr;
	String actual;
	
	
	@FindBy(xpath = "//a[@href = '/logout']")
	WebElement logout;
	
	public MyAccount(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public String verifyTitle() {	

		WebDriverWait wt = new WebDriverWait(dr, 4);
		wt.until(ExpectedConditions.titleContains("Demo Web Shop"));
		
		actual = dr.getTitle();
		return actual;
	}
	
	public void checkLogout() {
		
		try {
			if(logout.isDisplayed()) {
				logout.click();
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
